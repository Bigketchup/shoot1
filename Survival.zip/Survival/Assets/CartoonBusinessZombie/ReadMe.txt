Included is the fbx model,texture, and a compressed blend file. This asset is simply a rigged model. There are no scipts or animation controllers. 

The unity scene has the texture set up on a unlit shader material which is applied to the model. He was custom rigged in blender to work with humaniod mecanim animations.


